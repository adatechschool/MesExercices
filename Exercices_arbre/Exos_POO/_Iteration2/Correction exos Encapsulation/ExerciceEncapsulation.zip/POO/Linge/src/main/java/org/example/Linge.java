package org.example;

public class Linge {
    private String codeBarre;


    public Linge(String codeBarre) {
        this.codeBarre = codeBarre;
    }
}
