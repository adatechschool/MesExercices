package org.example;

public class Serviette extends Linge {
    public Serviette(String codeBarre) {
        super(codeBarre);
    }
}
