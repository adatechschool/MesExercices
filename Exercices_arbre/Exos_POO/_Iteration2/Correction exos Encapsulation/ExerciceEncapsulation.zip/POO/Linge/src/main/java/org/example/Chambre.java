package org.example;

import java.util.ArrayList;
import java.util.List;

public class Chambre {
    private int capacite;
    private List<Serviette> serviettes;
    private List<Drap> draps;
    private List<Peignoir> peignoirs;

    public Chambre(int capacite, List<Serviette> serviettes, List<Drap> draps, List<Peignoir> peignoirs) {
        this.capacite = capacite;
        this.serviettes = serviettes;
        this.draps = draps;
        this.peignoirs = peignoirs;
    }

    public Chambre(int capacite) {
        this.capacite = capacite;
        this.peignoirs = new ArrayList<>();
        this.draps = new ArrayList<>();
        this.serviettes = new ArrayList<>();
    }

    public int getCapacite() {
        return capacite;
    }

    public void setCapacite(int capacite) {
        this.capacite = capacite;
    }

    public List<Serviette> getServiettes() {
        return serviettes;
    }

    public List<Drap> getDraps() {
        return draps;
    }

    public List<Peignoir> getPeignoirs() {
        return peignoirs;
    }

    public void addLinge(Linge monLinge){
        if(monLinge instanceof Drap){
            if(draps.size()<capacite){
                draps.add( (Drap) monLinge);
            }
            else{
                System.out.println("Impossible d'ajouter le drap");
            }
        }
        if(monLinge instanceof Serviette){
            if(serviettes.size()<capacite){
                serviettes.add( (Serviette) monLinge);
            }
            else{
                System.out.println("Impossible d'ajouter la serviette");
            }
        }
        if(monLinge instanceof Peignoir){
            if(peignoirs.size()<capacite){
                peignoirs.add( (Peignoir) monLinge);
            }
            else{
                System.out.println("Impossible d'ajouter le peignoir");
            }
        }

    }


}
