package org.example;

public class Main {
    public static void main(String[] args) {

        Chambre maChambre = new Chambre(3);
        maChambre.addLinge(new Serviette("fsdfdsfsd"));
        maChambre.addLinge(new Serviette("kjh,nbd"));
        maChambre.addLinge(new Serviette("hgfgd"));
        maChambre.addLinge(new Serviette("fsdfdsfsd"));
        maChambre.addLinge(new Serviette("fsdfdsfsd"));
        maChambre.addLinge(new Peignoir("gfdhc"));
        maChambre.addLinge(new Drap("fsdgd"));
    }
}