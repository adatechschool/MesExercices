package org.example;

public class Peignoir extends Linge{

    public Peignoir(String codeBarre) {
        super(codeBarre);
    }
}
