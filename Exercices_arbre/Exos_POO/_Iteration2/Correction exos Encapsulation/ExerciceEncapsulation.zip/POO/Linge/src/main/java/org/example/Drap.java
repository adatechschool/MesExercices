package org.example;

public class Drap extends Linge{
    public Drap(String codeBarre) {
        super(codeBarre);
    }
}
