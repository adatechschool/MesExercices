package org.example;

import java.util.Date;

public class Film {
    private String titre;
    private Date dateDeSortie;
    private Realisatrice realisatrice;

    public Film(String titre, Date dateDeSortie, Realisatrice realisatrice) {
        this.titre = titre;
        this.dateDeSortie = dateDeSortie;
        this.realisatrice = realisatrice;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public Date getDateDeSortie() {
        return dateDeSortie;
    }

    public void setDateDeSortie(Date dateDeSortie) {
        this.dateDeSortie = dateDeSortie;
    }

    public Realisatrice getRealisatrice() {
        return realisatrice;
    }

    public void setRealisatrice(Realisatrice realisatrice) {
        this.realisatrice = realisatrice;
    }
}
