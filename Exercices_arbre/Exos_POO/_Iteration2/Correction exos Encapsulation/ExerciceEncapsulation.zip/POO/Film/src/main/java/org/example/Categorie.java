package org.example;

public class Categorie {
    private String nom;
    private TypeCategorie type;

    public Categorie(String nom, TypeCategorie type) {
        this.nom = nom;
        this.type = type;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public TypeCategorie getType() {
        return type;
    }

    public void setType(TypeCategorie type) {
        this.type = type;
    }
}
