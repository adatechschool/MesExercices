package org.example;

public enum TypeCategorie {
    FICTION,
    DOCUMENTAIRE
}
