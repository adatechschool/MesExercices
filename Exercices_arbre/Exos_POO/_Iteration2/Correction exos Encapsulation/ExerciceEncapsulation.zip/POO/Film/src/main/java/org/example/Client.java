package org.example;

import java.util.ArrayList;
import java.util.List;

public class Client extends Personne{
    private List<Film> filmEnLocation;

    public List<Film> getFilmEnLocation() {
        return filmEnLocation;
    }

    public void setFilmEnLocation(List<Film> filmEnLocation) {
        this.filmEnLocation = filmEnLocation;
    }

    public Client(String nom, String prenom) {
        super(nom, prenom);
        this.filmEnLocation = new ArrayList<>();
    }

    public void louerFilm(Film film){
        if(this.filmEnLocation.size()>=2){
            System.out.println("Impossible de louer un film "+film.getTitre());
        }
        else{
            this.filmEnLocation.add(film);
        }
    }
}
