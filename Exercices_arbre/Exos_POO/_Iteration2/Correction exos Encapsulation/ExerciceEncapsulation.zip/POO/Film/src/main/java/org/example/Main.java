package org.example;

import java.time.LocalDate;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");

        Realisatrice r = new Realisatrice("Ada","Lovelace", LocalDate.now());
        Film f1 = new Film("tre",new Date(),r);
        Film f2 = new Film("Toto",new Date(),r);
        Film f3 = new Film("Tata",new Date(),r);
        Film f4 = new Film("Titi",new Date(),r);

        Client c = new Client("Robert","Client");
        c.louerFilm(f1);
        c.louerFilm(f2);
        c.louerFilm(f3);
        c.louerFilm(f4);

    }
}