package org.example;

import java.time.LocalDate;
import java.time.Period;

public class Realisatrice extends Personne{
    private LocalDate dateDeNaissance;
    private int age;

    public Realisatrice(String nom, String prenom, LocalDate dateDeNaissance) {
        super(nom,prenom);
        this.dateDeNaissance = dateDeNaissance;
        this.age = Period.between(dateDeNaissance, LocalDate.now()).getYears();
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public LocalDate getDateDeNaissance() {
        return dateDeNaissance;
    }

    public void setDateDeNaissance(LocalDate dateDeNaissance) {
        this.dateDeNaissance = dateDeNaissance;
    }
}
