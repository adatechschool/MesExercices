<?php

class LoggerFactory
{
    public function createLogger($typeOfLogger = 'file')
    {
        if($typeOfLogger === 'file') {
            return new LoggerFile();
            // c'est un loggerFile
        } elseif($typeOfLogger === 'db') {
            return new LoggerDb();
            // C'est un loggerDb
        }
    }
}

class LoggerFile
{
    public function log()
    {
        var_dump('Log dans un fichier');
    }
}

class LoggerDb
{
    public function log()
    {
        var_dump('Log dans une base de donnée');
    }
}

$loggerFile = new LoggerFile();
$loggerFile->log();