<?php
// Définition de l'interface pour les produits
interface Logger {
    public function log(string $message): void;
}

// Implémentation concrète d'un produit
class FileLogger implements Logger {
    public function log(string $message): void {
        // Logique pour écrire dans un fichier
        echo "Logging to file: $message\n";
    }
}

// Implémentation concrète d'un autre produit
class DatabaseLogger implements Logger {
    public function log(string $message): void {
        // Logique pour écrire dans une base de données
        echo "Logging to database: $message\n";
    }
}

// Classe Factory pour créer des instances de Logger
class LoggerFactory {
    public static function createLogger(string $type): ?Logger {
        // Logique pour créer et retourner une instance de Logger
        if ($type === 'file') {
            return new FileLogger();
        } elseif ($type === 'database') {
            return new DatabaseLogger();
        }
        return null; // Retourne null si le type n'est pas reconnu
    }
}

// Utilisation de la Factory pour créer des instances de Logger
$fileLogger = LoggerFactory::createLogger('file');
if ($fileLogger !== null) {
    $fileLogger->log("This is a file log message.");
}

$dbLogger = LoggerFactory::createLogger('database');
if ($dbLogger !== null) {
    $dbLogger->log("This is a database log message.");
}
?>